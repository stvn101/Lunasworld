"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Star, Music, VolumeX, Volume2 } from "lucide-react";
import { useInView } from "react-intersection-observer";
import { useSound } from "@/components/sound-context";

export default function Home() {
  const { soundEnabled, musicEnabled, toggleSound, toggleMusic, playSound } = useSound();
  
  const [titleRef, titleInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  const [characterRef, characterInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });
  
  const [buttonsRef, buttonsInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const handleSoundToggle = () => {
    toggleSound();
    playSound("click");
  };

  const handleMusicToggle = () => {
    toggleMusic();
    playSound("click");
  };

  const handleButtonClick = () => {
    playSound("click");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <motion.div 
        ref={titleRef}
        initial={{ opacity: 0, y: -50 }}
        animate={titleInView ? { opacity: 1, y: 0 } : { opacity: 0, y: -50 }}
        transition={{ duration: 0.8 }}
        className="text-center mb-12"
      >
        <div className="relative w-64 h-64 mx-auto mb-6">
          <Image
            src="/game_logo.png"
            alt="Luna's World Logo"
            fill
            className="object-contain animate-float"
            priority
          />
        </div>
        <h1 className="text-5xl font-bold text-primary mb-4">Luna's World</h1>
        <p className="text-xl text-muted-foreground max-w-md mx-auto">
          A magical adventure for young explorers! Discover exciting places and make new friends.
        </p>
      </motion.div>

      <motion.div
        ref={characterRef}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={characterInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="mb-12"
      >
        <div className="relative w-72 h-72 mx-auto">
          <Image
            src="/hamster_character.png"
            alt="Luna the Hamster"
            fill
            className="object-contain animate-bounce-slow"
          />
        </div>
      </motion.div>

      <motion.div
        ref={buttonsRef}
        initial={{ opacity: 0, y: 50 }}
        animate={buttonsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
        transition={{ duration: 0.8, delay: 0.6 }}
        className="flex flex-col items-center gap-4"
      >
        <Link 
          href="/map" 
          className="game-button bg-secondary w-64 flex items-center justify-center gap-2"
          onClick={handleButtonClick}
        >
          <Star className="w-6 h-6" />
          Start Playing
        </Link>
        
        <Link 
          href="/character" 
          className="game-button bg-accent text-accent-foreground w-64"
          onClick={handleButtonClick}
        >
          Create Character
        </Link>
        
        <div className="flex gap-4 mt-4">
          <button
            onClick={handleSoundToggle}
            className="p-4 rounded-full bg-muted hover:bg-muted/80 transition-colors"
            aria-label={soundEnabled ? "Disable sound effects" : "Enable sound effects"}
          >
            {soundEnabled ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
          </button>
          
          <button
            onClick={handleMusicToggle}
            className="p-4 rounded-full bg-muted hover:bg-muted/80 transition-colors"
            aria-label={musicEnabled ? "Disable music" : "Enable music"}
          >
            <Music className={`w-6 h-6 ${musicEnabled ? "" : "line-through"}`} />
          </button>
        </div>
      </motion.div>
    </div>
  );
}