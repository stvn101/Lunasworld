"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { Home, School, Tree, Castle, PawPrint, VolumeX, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ModeToggle } from "@/components/mode-toggle";
import { useSound } from "@/hooks/use-sound";

const Header = () => {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const { isMuted, toggleMute, playSound } = useSound();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleSoundToggle = () => {
    toggleMute(!isMuted);
    playSound("click");
  };

  const navItems = [
    {
      name: "Home",
      path: "/",
      icon: <Home className="h-5 w-5 mr-1" />,
    },
    {
      name: "Cozy Cottage",
      path: "/environments/cozy-cottage",
      icon: <Home className="h-5 w-5 mr-1" />,
    },
    {
      name: "Adventure School",
      path: "/environments/adventure-school",
      icon: <School className="h-5 w-5 mr-1" />,
    },
    {
      name: "Sunny Park",
      path: "/environments/sunny-park",
      icon: <Tree className="h-5 w-5 mr-1" />,
    },
    {
      name: "Magic Kingdom",
      path: "/environments/magic-kingdom",
      icon: <Castle className="h-5 w-5 mr-1" />,
    },
    {
      name: "Pet Store",
      path: "/environments/pet-store",
      icon: <PawPrint className="h-5 w-5 mr-1" />,
    },
  ];

  return (
    <motion.header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? "bg-white/80 dark:bg-slate-900/80 backdrop-blur-md shadow-md"
          : "bg-transparent"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <div className="container mx-auto max-w-6xl px-4 py-3 flex flex-wrap items-center justify-between">
        <Link href="/" className="flex items-center" onClick={() => playSound("click")}>
          <span className="text-2xl font-bold bg-gradient-to-r from-red-500 to-purple-600 text-transparent bg-clip-text">
            Luna&apos;s World
          </span>
        </Link>

        <div className="flex items-center space-x-2 md:hidden">
          <button
            onClick={handleSoundToggle}
            className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800"
          >
            {isMuted ? (
              <VolumeX className="h-5 w-5 text-red-500" />
            ) : (
              <Volume2 className="h-5 w-5 text-green-500" />
            )}
          </button>
          <ModeToggle />
        </div>

        <nav className="hidden md:flex items-center space-x-1 overflow-x-auto">
          {navItems.map((item) => {
            const isActive = pathname === item.path;
            return (
              <Link
                key={item.path}
                href={item.path}
                onClick={() => playSound("click")}
              >
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={`flex items-center ${
                    isActive ? "bg-red-500 hover:bg-red-600 text-white" : ""
                  }`}
                >
                  {item.icon}
                  {item.name}
                </Button>
              </Link>
            );
          })}
          <div className="flex items-center ml-2 space-x-2">
            <button
              onClick={handleSoundToggle}
              className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800"
            >
              {isMuted ? (
                <VolumeX className="h-5 w-5 text-red-500" />
              ) : (
                <Volume2 className="h-5 w-5 text-green-500" />
              )}
            </button>
            <ModeToggle />
          </div>
        </nav>

        <div className="block md:hidden mt-4 w-full overflow-x-auto pb-2">
          <div className="flex space-x-1">
            {navItems.map((item) => {
              const isActive = pathname === item.path;
              return (
                <Link
                  key={item.path}
                  href={item.path}
                  onClick={() => playSound("click")}
                >
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    size="sm"
                    className={`flex items-center whitespace-nowrap ${
                      isActive ? "bg-red-500 hover:bg-red-600 text-white" : ""
                    }`}
                  >
                    {item.icon}
                    {item.name}
                  </Button>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;