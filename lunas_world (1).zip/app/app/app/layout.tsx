import "./globals.css";
import { Inter } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Luna's World",
  description: "An interactive game for children with multiple environments to explore",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <main className="min-h-screen bg-gradient-to-b from-pink-50 to-purple-100 dark:from-purple-950 dark:to-indigo-950">
          {children}
        </main>
      </body>
    </html>
  );
}