import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Heart, Coffee, Book, Music, Bath, Utensils } from "lucide-react";

export default function CozyCottage() {
  const rooms = [
    {
      id: "living-room",
      name: "Living Room",
      description: "A cozy space with a fireplace and comfortable seating",
      image: "https://i.pinimg.com/originals/7f/f4/72/7ff472c39f1f391e8ee89aec7f0364e7.jpg",
    },
    {
      id: "kitchen",
      name: "Kitchen",
      description: "A warm kitchen with everything you need to cook delicious meals",
      image: "https://i.pinimg.com/originals/7c/e0/8b/7ce08b42a3d7ec6d3c2f464d5b96b344.png",
    },
    {
      id: "bedroom",
      name: "Bedroom",
      description: "A comfortable bedroom for rest and relaxation",
      image: "https://i.pinimg.com/originals/e9/f1/cd/e9f1cd1f9d1a8409a7056d97961d9d0f.jpg",
    },
    {
      id: "bathroom",
      name: "Bathroom",
      description: "A clean and bright bathroom with a bathtub",
      image: "https://i.pinimg.com/originals/e9/f1/cd/e9f1cd1f9d1a8409a7056d97961d9d0f.jpg",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-red-600 dark:text-red-400 mb-4">
          Cozy Cottage
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
          Welcome to Luna&apos;s cozy cottage! Explore different rooms and discover special items. 
          This is a warm and inviting home with many rooms to explore and activities to enjoy.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {rooms.map((room) => (
          <div
            key={room.id}
            className="environment-card bg-white/90 dark:bg-slate-800/90"
          >
            <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
              <Image
                src={room.image}
                alt={room.name}
                fill
                className="object-cover environment-image"
              />
            </div>
            <h3 className="text-2xl font-bold mb-2 text-red-500">{room.name}</h3>
            <p className="text-gray-700 dark:text-gray-300">{room.description}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <Link href="/">
          <Button className="bg-red-500 hover:bg-red-600">
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}