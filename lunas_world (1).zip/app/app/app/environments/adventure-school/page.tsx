import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { BookOpen, Palette, Calculator, Microscope, Music, Trophy } from "lucide-react";

export default function AdventureSchool() {
  const areas = [
    {
      id: "classroom",
      name: "Classroom",
      description: "Learn exciting subjects with fun interactive lessons",
      image: "https://i.pinimg.com/736x/1f/e1/15/1fe115f490ce04ee72bc609da8425640.jpg",
    },
    {
      id: "art-room",
      name: "Art Room",
      description: "Express your creativity through various art projects",
      image: "https://i.pinimg.com/originals/f1/7e/99/f17e993a3b1ce87fa1616d14484efae3.jpg",
    },
    {
      id: "science-lab",
      name: "Science Lab",
      description: "Discover the wonders of science through experiments",
      image: "https://i.pinimg.com/736x/bb/dc/f3/bbdcf35d629d586566300aeb13c8bc74.jpg",
    },
    {
      id: "music-room",
      name: "Music Room",
      description: "Learn to play instruments and enjoy music",
      image: "https://i.ytimg.com/vi/R2CV4kYiRnc/maxresdefault.jpg",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-blue-600 dark:text-blue-400 mb-4">
          Adventure School
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
          Welcome to Luna&apos;s Adventure School! Explore different areas of the school and discover fun learning activities.
          Learn and play with friends in this magical school environment.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {areas.map((area) => (
          <div
            key={area.id}
            className="environment-card bg-white/90 dark:bg-slate-800/90"
          >
            <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
              <Image
                src={area.image}
                alt={area.name}
                fill
                className="object-cover environment-image"
              />
            </div>
            <h3 className="text-2xl font-bold mb-2 text-blue-500">{area.name}</h3>
            <p className="text-gray-700 dark:text-gray-300">{area.description}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <Link href="/">
          <Button className="bg-blue-500 hover:bg-blue-600">
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}