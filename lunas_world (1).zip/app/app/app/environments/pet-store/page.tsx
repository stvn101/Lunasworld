import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { PawPrint, Heart, Cat, Dog, Bird, Fish } from "lucide-react";

export default function PetStore() {
  const areas = [
    {
      id: "hamster-haven",
      name: "Hamster Haven",
      description: "Meet adorable hamsters of different colors and personalities",
      image: "https://img.freepik.com/premium-vector/set-colorful-cages-animals-cartoon-style-house-pets-vector-illustration-supplies-parrots-hamsters-goods-pet-shops-white-background_812561-74.jpg?w=740",
    },
    {
      id: "puppy-palace",
      name: "Puppy Palace",
      description: "Play with friendly puppies of various breeds",
      image: "https://i.pinimg.com/736x/dc/77/fb/dc77fbd28d9a786ccec9939c4347c5d4.jpg",
    },
    {
      id: "kitty-corner",
      name: "Kitty Corner",
      description: "Meet playful kittens and learn about cat care",
      image: "https://i.pinimg.com/originals/6d/06/01/6d060130c58debd6b4077637cadb4fd0.jpg",
    },
    {
      id: "aquarium-adventure",
      name: "Aquarium Adventure",
      description: "Discover colorful fish and underwater creatures",
      image: "https://i.pinimg.com/originals/e7/cf/61/e7cf618a6c401651657347fcabfdc92d.jpg",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-red-600 dark:text-red-400 mb-4">
          Pet Store
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
          Welcome to Luna&apos;s Pet Store! Meet adorable animals, learn about pet care, and make new furry friends.
          Our special Hamster Haven features the cutest hamsters waiting to meet you!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {areas.map((area) => (
          <div
            key={area.id}
            className="environment-card bg-white/90 dark:bg-slate-800/90"
          >
            <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
              <Image
                src={area.image}
                alt={area.name}
                fill
                className="object-cover environment-image"
              />
            </div>
            <h3 className="text-2xl font-bold mb-2 text-red-500">{area.name}</h3>
            <p className="text-gray-700 dark:text-gray-300">{area.description}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <Link href="/">
          <Button className="bg-red-500 hover:bg-red-600">
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}