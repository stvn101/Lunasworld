import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Flower, Cloud, Bird, Fish, Leaf } from "lucide-react";

export default function SunnyPark() {
  const areas = [
    {
      id: "playground",
      name: "Playground",
      description: "Play on slides, swings, and climbing structures",
      image: "https://img.freepik.com/premium-photo/kids-playground-sunny-weather-empty-children-area-with-slides-sandbox-swings-playing-recreation-fun-park-garden-house-backyard-kindergarten-field-cartoon-vector-illustration_760214-7097.jpg",
    },
    {
      id: "garden",
      name: "Flower Garden",
      description: "Explore beautiful flowers and plants",
      image: "https://i.pinimg.com/originals/20/f6/b0/20f6b0dbb6e0dbdd6cff0350e00f28a9.jpg",
    },
    {
      id: "pond",
      name: "Duck Pond",
      description: "Visit the pond and feed the ducks",
      image: "https://i.pinimg.com/originals/51/e3/2a/51e32a12c98eb67da692455bc1fc50dc.jpg",
    },
    {
      id: "picnic-area",
      name: "Picnic Area",
      description: "Enjoy a delicious picnic under shady trees",
      image: "https://png.pngtree.com/png-clipart/20230913/original/pngtree-outdoor-clipart-picnic-table-cartoon-cartoon-with-trees-vector-png-image_11063016.png",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-green-600 dark:text-green-400 mb-4">
          Sunny Park
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
          Welcome to Luna&apos;s Sunny Park! Explore the outdoors, play on the playground, and discover nature.
          Enjoy outdoor activities in this beautiful park with friends.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {areas.map((area) => (
          <div
            key={area.id}
            className="environment-card bg-white/90 dark:bg-slate-800/90"
          >
            <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
              <Image
                src={area.image}
                alt={area.name}
                fill
                className="object-cover environment-image"
              />
            </div>
            <h3 className="text-2xl font-bold mb-2 text-green-500">{area.name}</h3>
            <p className="text-gray-700 dark:text-gray-300">{area.description}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <Link href="/">
          <Button className="bg-green-500 hover:bg-green-600">
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}