import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Sparkles, Crown, Wand2, Star, Gem } from "lucide-react";

export default function MagicKingdom() {
  const areas = [
    {
      id: "castle",
      name: "Enchanted Castle",
      description: "Explore the magical castle with hidden secrets",
      image: "https://i.pinimg.com/736x/45/c8/f1/45c8f19c230d8493856b94c3f2d836d8.jpg",
    },
    {
      id: "fairy-forest",
      name: "Fairy Forest",
      description: "Meet magical fairies and discover enchanted plants",
      image: "https://i.ytimg.com/vi/syp6Lsd8HOo/maxresdefault.jpg",
    },
    {
      id: "wizard-tower",
      name: "Wizard Tower",
      description: "Learn magic spells and potions from friendly wizards",
      image: "https://i.pinimg.com/originals/d4/df/d7/d4dfd75d78681ea992f7ee2351ad31b8.jpg",
    },
    {
      id: "dragon-valley",
      name: "Dragon Valley",
      description: "Meet friendly dragons and learn about their magic",
      image: "https://i.pinimg.com/originals/a6/83/47/a683478ad4a4646aec1289f1b97ac74d.jpg",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-purple-600 dark:text-purple-400 mb-4">
          Magic Kingdom
        </h1>
        <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
          Welcome to Luna&apos;s Magic Kingdom! Discover magical creatures, cast spells, and explore enchanted places.
          This is a realm of wonder where imagination comes to life.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {areas.map((area) => (
          <div
            key={area.id}
            className="environment-card bg-white/90 dark:bg-slate-800/90"
          >
            <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
              <Image
                src={area.image}
                alt={area.name}
                fill
                className="object-cover environment-image"
              />
            </div>
            <h3 className="text-2xl font-bold mb-2 text-purple-500">{area.name}</h3>
            <p className="text-gray-700 dark:text-gray-300">{area.description}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <Link href="/">
          <Button className="bg-purple-500 hover:bg-purple-600">
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}