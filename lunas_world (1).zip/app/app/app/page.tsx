import Link from "next/link";
import Image from "next/image";
import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const environments = [
    {
      name: "Cozy Cottage",
      description: "A warm and inviting home with many rooms to explore",
      image: "https://i.pinimg.com/736x/f6/56/00/f65600794f1b24f89aa6e6345803c7a7.jpg",
      path: "/environments/cozy-cottage",
      color: "from-red-100 to-orange-200 dark:from-red-950 dark:to-orange-900",
    },
    {
      name: "Adventure School",
      description: "Learn and play with friends in this magical school",
      image: "https://i.pinimg.com/originals/a2/5d/e7/a25de7d5250c03a33409b084f36b2b90.jpg",
      path: "/environments/adventure-school",
      color: "from-blue-100 to-indigo-200 dark:from-blue-950 dark:to-indigo-900",
    },
    {
      name: "Sunny Park",
      description: "Enjoy outdoor activities in this beautiful park",
      image: "https://i.pinimg.com/originals/20/dd/bd/20ddbd9d0ace6be3e0b95aa985df5595.jpg",
      path: "/environments/sunny-park",
      color: "from-green-100 to-emerald-200 dark:from-green-950 dark:to-emerald-900",
    },
    {
      name: "Magic Kingdom",
      description: "Discover magical creatures and enchanted places",
      image: "https://thumbs.dreamstime.com/z/cute-cartoon-castle-fairytale-cartoon-castle-fantasy-fairy-tale-palace-rainbow-vector-illustration-cute-cartoon-castle-164569732.jpg",
      path: "/environments/magic-kingdom",
      color: "from-purple-100 to-violet-200 dark:from-purple-950 dark:to-violet-900",
    },
    {
      name: "Pet Store",
      description: "Meet adorable pets including hamsters waiting for you",
      image: "https://img.freepik.com/premium-vector/vector-illustration-funny-interior-pet-shop-cartoon-style-house-pets-vector-illustration-supplies-parrots-hamsters-goods-pet-shops-white-background_812561-74.jpg?w=2000",
      path: "/environments/pet-store",
      color: "from-red-200 to-pink-200 dark:from-red-900 dark:to-pink-900",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-red-500 via-purple-500 to-pink-500 text-transparent bg-clip-text mb-4">
          Welcome to Luna&apos;s World
        </h1>
        <p className="text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
          Explore magical environments, make new friends, and embark on exciting adventures!
        </p>
      </div>

      <div className="relative w-full aspect-[16/9] max-w-4xl mx-auto mb-12 rounded-2xl overflow-hidden shadow-2xl">
        <Image
          src="https://i.pinimg.com/originals/5d/7e/2e/5d7e2ef39ad00664e09aed8724d7a402.jpg"
          alt="Luna's World"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end justify-center p-8">
          <Link href="/environments/cozy-cottage">
            <Button size="lg" className="bg-red-500 hover:bg-red-600 text-white font-bold text-lg px-8 py-6 rounded-full shadow-lg">
              <Play className="mr-2 h-6 w-6" /> Start Playing
            </Button>
          </Link>
        </div>
      </div>

      <h2 className="text-3xl font-bold text-center mb-8 text-gray-800 dark:text-gray-200">
        Explore Magical Environments
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {environments.map((env) => (
          <div key={env.name}>
            <Link href={env.path}>
              <div className={`rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 h-full bg-gradient-to-br ${env.color}`}>
                <div className="relative h-48">
                  <Image
                    src={env.image}
                    alt={env.name}
                    fill
                    className="object-cover environment-image"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-2">{env.name}</h3>
                  <p className="text-gray-700 dark:text-gray-300">{env.description}</p>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>

      <div className="bg-white/80 dark:bg-slate-800/80 rounded-xl p-8 shadow-lg">
        <h2 className="text-2xl font-bold mb-4 text-red-500">New in Luna&apos;s World!</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex items-start space-x-4">
            <div className="bg-red-100 dark:bg-red-900/50 p-3 rounded-full">
              <div className="w-[60px] h-[60px] relative rounded-full overflow-hidden">
                <Image
                  src="https://static.vecteezy.com/system/resources/previews/017/048/296/original/cute-hamster-illustration-hamster-kawaii-chibi-drawing-style-hamster-cartoon-vector.jpg"
                  alt="Hamster"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-1">Pet Store with Hamsters</h3>
              <p className="text-gray-600 dark:text-gray-400">Visit our new Pet Store to meet adorable hamsters and other furry friends!</p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <div className="bg-purple-100 dark:bg-purple-900/50 p-3 rounded-full">
              <div className="w-[60px] h-[60px] relative rounded-full overflow-hidden">
                <Image
                  src="https://i.pinimg.com/originals/f0/ee/a2/f0eea22add6500a24b0b23a265f6ba3b.jpg"
                  alt="Spa Day"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-1">Spa Day Activities</h3>
              <p className="text-gray-600 dark:text-gray-400">Relax and enjoy new spa activities across different environments!</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}