"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Home, School, Trees, Crown, ArrowLeft, Mouse, Sparkles } from "lucide-react";
import { useInView } from "react-intersection-observer";
import { useSound } from "@/components/sound-context";

export default function MapPage() {
  const { playSound } = useSound();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const locations = [
    {
      id: "cozy-cottage",
      name: "Cozy Cottage",
      description: "A warm and friendly home with lots to explore",
      icon: <Home className="w-8 h-8 text-secondary" />,
      color: "bg-gradient-to-br from-pink-100 to-pink-200",
    },
    {
      id: "adventure-school",
      name: "Adventure School",
      description: "Learn and play with fun activities",
      icon: <School className="w-8 h-8 text-primary" />,
      color: "bg-gradient-to-br from-purple-100 to-purple-200",
    },
    {
      id: "sunny-park",
      name: "Sunny Park",
      description: "Enjoy outdoor fun in the sunshine",
      icon: <Trees className="w-8 h-8 text-green-500" />,
      color: "bg-gradient-to-br from-green-100 to-green-200",
    },
    {
      id: "magic-kingdom",
      name: "Magic Kingdom",
      description: "Discover magical wonders and surprises",
      icon: <Crown className="w-8 h-8 text-yellow-500" />,
      color: "bg-gradient-to-br from-yellow-100 to-yellow-200",
    },
    {
      id: "pet-store",
      name: "Pet Store",
      description: "Meet and adopt cute animal friends",
      icon: <Mouse className="w-8 h-8 text-amber-500" />,
      color: "bg-gradient-to-br from-amber-100 to-amber-200",
    },
    {
      id: "spa-day",
      name: "Spa Day",
      description: "Relax and get pampered with fun treatments",
      icon: <Sparkles className="w-8 h-8 text-pink-500" />,
      color: "bg-gradient-to-br from-pink-100 to-pink-200",
    }
  ];

  const handleLocationClick = (id: string) => {
    playSound("click");
    // In a full implementation, this would navigate to the location
    console.log(`Navigating to ${id}`);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <Link href="/" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-6 h-6" />
            <span className="text-lg font-medium">Back to Home</span>
          </Link>
          
          <h1 className="text-3xl font-bold text-center text-primary">Choose a Place to Visit</h1>
        </div>

        <motion.div 
          ref={ref}
          variants={container}
          initial="hidden"
          animate={inView ? "show" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {locations.map((location) => (
            <motion.div key={location.id} variants={item}>
              <button 
                onClick={() => handleLocationClick(location.id)}
                className="w-full text-left"
              >
                <div className={`map-location ${location.color} h-full`}>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 bg-white rounded-full shadow-md">
                      {location.icon}
                    </div>
                    <h2 className="text-2xl font-bold">{location.name}</h2>
                  </div>
                  
                  <p className="text-lg mb-4">{location.description}</p>
                  
                  <div className="bg-white/50 p-4 rounded-xl">
                    <div className="aspect-[4/3] relative rounded-lg overflow-hidden">
                      {location.id === "cozy-cottage" ? (
                        <Image 
                          src="/cozy_cottage_scene.png" 
                          alt={location.name}
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <p className="text-muted-foreground">Preview coming soon!</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}