import { redirect } from 'next/navigation';

export default function CozyCottagePage() {
  redirect('/map');
}