"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Trees, Cloud, Sun, Flower, Bird } from "lucide-react";
import { useInView } from "react-intersection-observer";

export default function SunnyParkPage() {
  const [currentArea, setCurrentArea] = useState("");
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const areas = [
    { id: "playground", name: "Playground", icon: <Cloud className="w-6 h-6" />, color: "bg-blue-100" },
    { id: "garden", name: "Flower Garden", icon: <Flower className="w-6 h-6" />, color: "bg-pink-100" },
    { id: "pond", name: "Duck Pond", icon: <Bird className="w-6 h-6" />, color: "bg-teal-100" },
    { id: "picnic", name: "Picnic Area", icon: <Sun className="w-6 h-6" />, color: "bg-yellow-100" },
  ];

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <Link href="/map" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-6 h-6" />
            <span className="text-lg font-medium">Back to Map</span>
          </Link>
          
          <h1 className="text-3xl font-bold text-center text-primary">Sunny Park</h1>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8 bg-card rounded-3xl p-6 shadow-lg"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-green-100 rounded-full">
              <Trees className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold">Welcome to Sunny Park!</h2>
          </div>
          
          <p className="text-lg mb-6">
            A beautiful outdoor space where Luna and friends can play in the sunshine. Explore different areas of the park!
          </p>
          
          <div className="aspect-video bg-muted rounded-xl flex items-center justify-center">
            <p className="text-muted-foreground text-lg">Sunny Park Scene Coming Soon!</p>
          </div>
        </motion.div>

        <motion.div
          ref={ref}
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-2 gap-4 mb-8"
        >
          {areas.map((area, index) => (
            <motion.div
              key={area.id}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
            >
              <button
                onClick={() => setCurrentArea(area.id)}
                className={`w-full p-6 rounded-2xl ${area.color} hover:shadow-lg transition-all duration-300 ${
                  currentArea === area.id ? "ring-4 ring-primary" : ""
                }`}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="p-4 bg-white rounded-full mb-3 shadow-md">
                    {area.icon}
                  </div>
                  <h3 className="text-xl font-bold">{area.name}</h3>
                </div>
              </button>
            </motion.div>
          ))}
        </motion.div>

        {currentArea && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.5 }}
            className="bg-card rounded-3xl p-6 shadow-lg overflow-hidden mb-8"
          >
            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
              {areas.find(a => a.id === currentArea)?.icon}
              {areas.find(a => a.id === currentArea)?.name}
            </h3>
            
            <div className="aspect-video bg-muted rounded-xl flex items-center justify-center mb-4">
              <p className="text-muted-foreground">Area content coming soon!</p>
            </div>
            
            <p className="text-lg">
              This is a fun area in the park where Luna and friends can play. Interactive elements will appear here in the full game.
            </p>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="bg-card rounded-3xl p-6 shadow-lg"
        >
          <h2 className="text-2xl font-bold mb-4">How to Play</h2>
          <ul className="space-y-2 text-lg">
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Click on different areas to explore the park</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Each area has unique activities and games</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Interact with nature and park elements</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Return to the map to visit other locations</span>
            </li>
          </ul>
        </motion.div>
      </div>
    </div>
  );
}