import { redirect } from 'next/navigation';

export default function MagicKingdomPage() {
  redirect('/map');
}