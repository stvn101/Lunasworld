import { redirect } from 'next/navigation';

export default function PetStorePage() {
  redirect('/map');
}