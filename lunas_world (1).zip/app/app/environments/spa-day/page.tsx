"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowLeft, Sparkles, Bath, Scissors, Paintbrush, Smile } from "lucide-react";
import { useInView } from "react-intersection-observer";

export default function SpaDayPage() {
  const [currentActivity, setCurrentActivity] = useState("");
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const activities = [
    { 
      id: "bath", 
      name: "Bubble Bath", 
      icon: <Bath className="w-6 h-6" />, 
      color: "bg-blue-100",
      description: "Relax in a warm bubble bath with colorful bath bombs and rubber duckies!"
    },
    { 
      id: "haircut", 
      name: "Haircut & Style", 
      icon: <Scissors className="w-6 h-6" />, 
      color: "bg-purple-100",
      description: "Get a fun new haircut and style with colorful clips and bows!"
    },
    { 
      id: "facepaint", 
      name: "Face Painting", 
      icon: <Paintbrush className="w-6 h-6" />, 
      color: "bg-pink-100",
      description: "Choose from butterflies, tigers, superheroes and more fun face paint designs!"
    },
    { 
      id: "massage", 
      name: "Relaxing Massage", 
      icon: <Smile className="w-6 h-6" />, 
      color: "bg-green-100",
      description: "Enjoy a gentle massage with scented oils to feel relaxed and happy!"
    }
  ];

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <Link href="/map" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-6 h-6" />
            <span className="text-lg font-medium">Back to Map</span>
          </Link>
          
          <h1 className="text-3xl font-bold text-center text-primary">Spa Day</h1>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8 bg-card rounded-3xl p-6 shadow-lg"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-pink-100 rounded-full">
              <Sparkles className="w-8 h-8 text-pink-600" />
            </div>
            <h2 className="text-2xl font-bold">Welcome to Spa Day!</h2>
          </div>
          
          <p className="text-lg mb-6">
            This is where Luna and friends can relax and get pampered! Choose an activity to start your spa day.
          </p>
          
          <div className="aspect-video bg-muted rounded-xl flex items-center justify-center">
            <p className="text-muted-foreground text-lg">
              {currentActivity 
                ? `${activities.find(a => a.id === currentActivity)?.name} Scene Coming Soon!` 
                : "Select an activity to begin!"}
            </p>
          </div>
        </motion.div>

        <motion.div
          ref={ref}
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-2 gap-4 mb-8"
        >
          {activities.map((activity, index) => (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
            >
              <button
                onClick={() => setCurrentActivity(activity.id)}
                className={`w-full p-6 rounded-2xl ${activity.color} hover:shadow-lg transition-all duration-300 ${
                  currentActivity === activity.id ? "ring-4 ring-primary" : ""
                }`}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="p-4 bg-white rounded-full mb-3 shadow-md">
                    {activity.icon}
                  </div>
                  <h3 className="text-xl font-bold">{activity.name}</h3>
                </div>
              </button>
            </motion.div>
          ))}
        </motion.div>

        {currentActivity && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.5 }}
            className="bg-card rounded-3xl p-6 shadow-lg overflow-hidden mb-8"
          >
            <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
              {activities.find(a => a.id === currentActivity)?.icon}
              {activities.find(a => a.id === currentActivity)?.name}
            </h3>
            
            <p className="text-lg mb-6">
              {activities.find(a => a.id === currentActivity)?.description}
            </p>
            
            <div className="flex justify-center">
              <button className="game-button bg-secondary">
                Start Activity
              </button>
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="bg-card rounded-3xl p-6 shadow-lg"
        >
          <h2 className="text-2xl font-bold mb-4">How to Play</h2>
          <ul className="space-y-2 text-lg">
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Click on different spa activities to try them</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Drag and drop items to help with each spa treatment</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Mix colors and create your own designs</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary text-2xl">•</span>
              <span>Return to the map to visit other locations</span>
            </li>
          </ul>
        </motion.div>
      </div>
    </div>
  );
}