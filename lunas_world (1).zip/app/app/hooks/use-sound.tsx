"use client";

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";

type SoundType = "click" | "success" | "error" | "background" | "interaction";

interface SoundContextType {
  playSound: (type: SoundType) => void;
  toggleMute: (mute: boolean) => void;
  isMuted: boolean;
}

const SoundContext = createContext<SoundContextType>({
  playSound: () => {},
  toggleMute: () => {},
  isMuted: true
});

export const SoundProvider = ({ children }: { children: ReactNode }) => {
  const [isMuted, setIsMuted] = useState(true);
  const [sounds, setSounds] = useState<Record<SoundType, HTMLAudioElement | null>>({
    click: null,
    success: null,
    error: null,
    background: null,
    interaction: null,
  });

  useEffect(() => {
    if (typeof window !== "undefined") {
      // Create audio elements but don't load them until needed
      setSounds({
        click: new Audio("/sounds/click.mp3"),
        success: new Audio("/sounds/success.mp3"),
        error: new Audio("/sounds/error.mp3"),
        background: new Audio("/sounds/background-music.mp3"),
        interaction: new Audio("/sounds/interaction.mp3"),
      });
    }
  }, []);

  useEffect(() => {
    if (sounds.background) {
      sounds.background.loop = true;
      
      const playBackgroundMusic = () => {
        if (!isMuted && sounds.background) {
          sounds.background.play().catch(() => {
            // Autoplay was prevented, we'll need user interaction
          });
        }
      };

      if (!isMuted) {
        playBackgroundMusic();
      } else if (sounds.background) {
        sounds.background.pause();
      }
    }

    return () => {
      if (sounds.background) {
        sounds.background.pause();
      }
    };
  }, [sounds.background, isMuted]);

  const playSound = useCallback(
    (type: SoundType) => {
      if (isMuted || !sounds[type]) return;
      
      try {
        // Clone the audio to allow multiple sounds to play simultaneously
        if (type !== "background") {
          const sound = sounds[type]!.cloneNode() as HTMLAudioElement;
          sound.volume = type === "click" ? 0.5 : 0.8;
          sound.play().catch(() => {
            // Handle autoplay restrictions
          });
        }
      } catch (error) {
        console.error("Error playing sound:", error);
      }
    },
    [sounds, isMuted]
  );

  const toggleMute = useCallback(
    (mute: boolean) => {
      setIsMuted(mute);
      if (mute && sounds.background) {
        sounds.background.pause();
      } else if (!mute && sounds.background) {
        sounds.background.play().catch(() => {
          // Autoplay was prevented
        });
      }
    },
    [sounds]
  );

  return (
    <SoundContext.Provider value={{ playSound, toggleMute, isMuted }}>
      {children}
    </SoundContext.Provider>
  );
};

export const useSound = () => {
  const context = useContext(SoundContext);
  return context;
};