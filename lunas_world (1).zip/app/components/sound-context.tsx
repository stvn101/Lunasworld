"use client";

import React, { createContext, useContext, useState, useEffect } from "react";

type SoundContextType = {
  soundEnabled: boolean;
  musicEnabled: boolean;
  toggleSound: () => void;
  toggleMusic: () => void;
  playSound: (soundName: string) => void;
};

const SoundContext = createContext<SoundContextType | undefined>(undefined);

export function SoundProvider({ children }: { children: React.ReactNode }) {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [sounds, setSounds] = useState<Record<string, HTMLAudioElement>>({});
  const [bgMusic, setBgMusic] = useState<HTMLAudioElement | null>(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    
    // Load sound preferences from localStorage if available
    const savedSound = localStorage.getItem("soundEnabled");
    const savedMusic = localStorage.getItem("musicEnabled");
    
    if (savedSound !== null) {
      setSoundEnabled(savedSound === "true");
    }
    
    if (savedMusic !== null) {
      setMusicEnabled(savedMusic === "true");
    }
    
    // Initialize sound effects (would be replaced with actual sound files)
    const soundEffects: Record<string, string> = {
      click: "/sounds/click.mp3",
      success: "/sounds/success.mp3",
      error: "/sounds/error.mp3",
    };
    
    // Preload sound effects
    const loadedSounds: Record<string, HTMLAudioElement> = {};
    Object.entries(soundEffects).forEach(([name, path]) => {
      try {
        // Only create audio elements on the client
        loadedSounds[name] = new Audio(path);
        loadedSounds[name].preload = "auto";
      } catch (error) {
        console.error(`Failed to load sound: ${name}`, error);
      }
    });
    setSounds(loadedSounds);
    
    // Initialize background music
    try {
      const music = new Audio("/sounds/background-music.mp3");
      music.loop = true;
      music.volume = 0.5;
      setBgMusic(music);
    } catch (error) {
      console.error("Failed to load background music", error);
    }
    
    // Cleanup function
    return () => {
      Object.values(loadedSounds).forEach(audio => {
        audio.pause();
        audio.src = "";
      });
      
      if (bgMusic) {
        bgMusic.pause();
        bgMusic.src = "";
      }
    };
  }, []);
  
  // Update background music when musicEnabled changes
  useEffect(() => {
    if (!isClient || !bgMusic) return;
    
    if (musicEnabled) {
      try {
        bgMusic.play().catch(error => {
          console.error("Failed to play background music", error);
        });
      } catch (error) {
        console.error("Error playing background music", error);
      }
    } else {
      bgMusic.pause();
    }
  }, [musicEnabled, bgMusic, isClient]);

  const toggleSound = () => {
    if (!isClient) return;
    
    const newValue = !soundEnabled;
    setSoundEnabled(newValue);
    localStorage.setItem("soundEnabled", String(newValue));
  };

  const toggleMusic = () => {
    if (!isClient) return;
    
    const newValue = !musicEnabled;
    setMusicEnabled(newValue);
    localStorage.setItem("musicEnabled", String(newValue));
  };

  const playSound = (soundName: string) => {
    if (!isClient || !soundEnabled || !sounds[soundName]) return;
    
    try {
      // Reset the audio to the beginning
      sounds[soundName].currentTime = 0;
      sounds[soundName].play().catch(error => {
        console.error(`Failed to play sound: ${soundName}`, error);
      });
    } catch (error) {
      console.error(`Error playing sound: ${soundName}`, error);
    }
  };

  return (
    <SoundContext.Provider
      value={{
        soundEnabled,
        musicEnabled,
        toggleSound,
        toggleMusic,
        playSound,
      }}
    >
      {children}
    </SoundContext.Provider>
  );
}

export function useSound() {
  const context = useContext(SoundContext);
  if (context === undefined) {
    throw new Error("useSound must be used within a SoundProvider");
  }
  return context;
}