"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { Home, Map, User, Settings, Volume2, VolumeX, Music } from "lucide-react";
import { useTheme } from "next-themes";
import { useSound } from "@/components/sound-context";

export default function Header() {
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();
  const { soundEnabled, musicEnabled, toggleSound, toggleMusic, playSound } = useSound();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleSoundToggle = () => {
    toggleSound();
    playSound("click");
  };

  const handleMusicToggle = () => {
    toggleMusic();
    playSound("click");
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
    playSound("click");
  };

  const navItems = [
    { href: "/", label: "Home", icon: <Home className="w-5 h-5" /> },
    { href: "/map", label: "Map", icon: <Map className="w-5 h-5" /> },
    { href: "/character", label: "Character", icon: <User className="w-5 h-5" /> },
  ];

  if (!mounted) {
    return null;
  }

  return (
    <header className="game-header py-3 px-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="relative w-10 h-10">
            <Image
              src="/game_logo.png"
              alt="Luna's World"
              fill
              className="object-contain"
            />
          </div>
          <span className="text-xl font-bold text-primary hidden sm:inline-block">Luna's World</span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href || 
              (item.href !== "/" && pathname.startsWith(item.href));
            
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`relative px-3 py-2 rounded-full flex items-center gap-1 transition-colors ${
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-muted"
                }`}
                onClick={() => playSound("click")}
              >
                {item.icon}
                <span className="hidden sm:inline-block">{item.label}</span>
                {isActive && (
                  <motion.div
                    className="absolute inset-0 rounded-full bg-primary -z-10"
                    layoutId="nav-highlight"
                    transition={{ type: "spring", duration: 0.5 }}
                  />
                )}
              </Link>
            );
          })}

          <div className="flex items-center gap-1 ml-2 border-l border-border pl-2">
            <button
              onClick={handleSoundToggle}
              className="p-2 rounded-full hover:bg-muted transition-colors"
              aria-label={soundEnabled ? "Disable sound effects" : "Enable sound effects"}
            >
              {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
            
            <button
              onClick={handleMusicToggle}
              className="p-2 rounded-full hover:bg-muted transition-colors"
              aria-label={musicEnabled ? "Disable music" : "Enable music"}
            >
              <Music className={`w-5 h-5 ${musicEnabled ? "" : "line-through"}`} />
            </button>
            
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-muted transition-colors"
              aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
}