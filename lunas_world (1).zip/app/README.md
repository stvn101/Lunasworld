# Luna's World

Luna's World is an interactive web-based game designed specifically for young children (around 5 years old), inspired by Toca World. The game features four vibrant, themed environments where children can explore and engage with colorful characters and objects.

## Features

- **Four Themed Environments:**
  - Cozy Cottage (kitchen, living room, bedroom with toys, bathroom)
  - Adventure School
  - Sunny Park
  - Magic Kingdom

- **Character Customization:** Create and customize your own character
- **Interactive Elements:** Click on objects to interact with them
- **Sound & Music Controls:** Toggle sound effects and music on/off
- **Progressive Web App:** Can be installed on devices for offline play

## Getting Started

### Prerequisites

- Node.js 18.0.0 or higher
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/lunas-world.git
cd lunas-world
```

2. Install dependencies:
```bash
npm install
# or
yarn install
```

3. Set up the database:
```bash
npx prisma migrate dev --name init
```

4. Start the development server:
```bash
npm run dev
# or
yarn dev
```

5. Open [http://localhost:3000](http://localhost:3000) in your browser to see the game.

## Deployment

The game can be deployed to any platform that supports Next.js applications, such as Vercel, Netlify, or a custom server.

To build the application for production:

```bash
npm run build
# or
yarn build
```

## Technologies Used

- Next.js 14
- React 18
- Tailwind CSS
- Framer Motion for animations
- Prisma for database management
- TypeScript

## License

This project is licensed under the MIT License - see the LICENSE file for details.